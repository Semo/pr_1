#ifndef MD5TOOL_H
#define MD5TOOL_H

/* calc and print MD5 checksum of a memory chunk */
char* getMD5DigestStr(void* buf, size_t buflen);

#endif /* MD5TOOL_h */
